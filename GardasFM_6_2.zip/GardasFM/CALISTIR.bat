@echo off
REM Gardas FM - kurulumdan sonra her seferinde bunu cift tiklayin
cd /d "%~dp0"
set "PYV="
for %%V in (3.13 3.12 3.11 3.14 3.10) do (
    if not defined PYV (
        py --list 2>nul | findstr /C:"%%V" >nul && set "PYV=%%V"
    )
)
if not defined PYV (
    call "%~dp0KUR_VE_CALISTIR.bat"
    exit /b
)
py -%PYV% -c "import customtkinter, vlc, yt_dlp, requests, PIL" >nul 2>&1
if errorlevel 1 (
    echo Gerekli paketler eksik, kurulum baslatiliyor...
    call "%~dp0KUR_VE_CALISTIR.bat"
    exit /b
)
py -%PYV% gardas_fm.py
if errorlevel 1 (
    echo.
    echo Bir hata olustu. Ekran goruntusu alip gonderin.
    pause
)
