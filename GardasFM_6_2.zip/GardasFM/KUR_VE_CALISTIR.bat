@echo off
REM Gardas FM - ILK KURULUM + CALISTIRMA (cift tiklayin, gerisini bu dosya yapar)
cd /d "%~dp0"
title Gardas FM - kurulum
echo ==========================================
echo   Gardas FM kuruluyor, bekleyin...
echo ==========================================
echo.

REM --- 1) Python var mi? Kararli surum 3.10 - 3.14 secilir, cok yeni 3.15 kullanilmaz.
where py >nul 2>&1
if errorlevel 1 (
    echo HATA: Python bulunamadi. python.org adresinden Python 3.13 kurun,
    echo kurulumda "Add python.exe to PATH" kutusunu isaretleyin, sonra bu dosyayi tekrar calistirin.
    pause
    exit /b 1
)
set "PYV="
for %%V in (3.13 3.12 3.11 3.14 3.10) do (
    if not defined PYV (
        py --list 2>nul | findstr /C:"%%V" >nul && set "PYV=%%V"
    )
)
if not defined PYV (
    echo Kararli bir Python bulunamadi, Python 3.13 kuruluyor... Windows izin sorarsa EVET deyin.
    winget install -e --id Python.Python.3.13 --accept-source-agreements --accept-package-agreements
    set "PYV=3.13"
)
echo Kullanilan Python: %PYV%

REM --- 2) VLC 64-bit var mi? Yoksa winget ile kur
if not exist "%ProgramFiles%\VideoLAN\VLC\libvlc.dll" (
    echo VLC bulunamadi, kuruluyor... Windows izin sorarsa EVET deyin.
    winget install --id VideoLAN.VLC -e --accept-source-agreements --accept-package-agreements
)
if not exist "%ProgramFiles%\VideoLAN\VLC\libvlc.dll" (
    echo.
    echo VLC otomatik kurulamadi. videolan.org adresinden 64-bit VLC'yi elle kurun,
    echo sonra bu dosyayi tekrar calistirin.
    pause
    exit /b 1
)

REM --- 3) Python paketleri
echo.
echo Python paketleri kuruluyor...
py -%PYV% -m pip install customtkinter python-vlc yt-dlp requests Pillow pystray pypresence
if errorlevel 1 (
    echo.
    echo HATA: Paketler kurulamadi. Internet baglantinizi kontrol edin.
    echo Python 3.13 kurulu degilse python.org adresinden kurup bu dosyayi tekrar calistirin.
    pause
    exit /b 1
)

REM --- 4) Calistir
echo.
echo Gardas FM aciliyor...
py -%PYV% gardas_fm.py
if errorlevel 1 (
    echo.
    echo Bir hata olustu. Yukaridaki yaziyi ekran goruntusu alip gonderin.
    pause
)
